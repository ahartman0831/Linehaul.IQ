declare const SchedulePage: React.ComponentType<any>;
export default SchedulePage;
