
import { useState } from 'react';
import { supabase } from '../../lib/supabaseClient';

const TimeOffForm = () => {
  const [driverId, setDriverId] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [status, setStatus] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from('time_off_requests').insert([
      { driver_id: driverId, start_date: startDate, end_date: endDate, reason }
    ]);

    if (error) {
      setStatus(`Error: ${error.message}`);
    } else {
      setStatus('Time off request submitted successfully.');
      setDriverId('');
      setStartDate('');
      setEndDate('');
      setReason('');
    }
  };

  return (
    <div className="p-4 border rounded shadow-md">
      <h3 className="text-lg font-bold mb-2">Submit Time Off Request</h3>
      <form onSubmit={handleSubmit}>
        <input type="text" value={driverId} onChange={(e) => setDriverId(e.target.value)} placeholder="Driver ID" className="border p-2 w-full mb-2" required />
        <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="border p-2 w-full mb-2" required />
        <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="border p-2 w-full mb-2" required />
        <textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Reason for time off" className="border p-2 w-full mb-2" required></textarea>
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Submit</button>
      </form>
      {status && <p className="mt-2">{status}</p>}
    </div>
  );
};

export default TimeOffForm;
