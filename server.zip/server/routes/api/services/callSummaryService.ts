// services/callSummaryService.ts

export async function getCallSummary(callId: string) {
  // Mock implementation for testing
  return { callId, summary: 'This is a mock call summary.' };
}