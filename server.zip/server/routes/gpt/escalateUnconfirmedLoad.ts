export function generateEscalationSummary(route: any): string {
  return `Escalation summary for route: ${route.id}`;
}
